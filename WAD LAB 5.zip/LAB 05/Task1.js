console.log(typeof 76543n);
console.log(typeof Symbol("Symbol"));