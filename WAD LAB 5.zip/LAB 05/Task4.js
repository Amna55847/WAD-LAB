let a=2;
console.log("a++ :"+a++);
console.log("++a :"+(++a));
console.log("a-- :"+a--);
console.log("--a :"+(--a));

