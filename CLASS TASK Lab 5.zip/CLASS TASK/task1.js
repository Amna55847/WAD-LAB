console.log("Amna");
fullName="Amna Zahood";
age=20;
price=89.99;
radius=14;
a=null;
y=undefined;
console.log(a);

var name="Amna";
console.log(name);

var name="Saira";
console.log(name);

var name="Zahra";
console.log(name);

if (true)
{
    var test="Inside block";
}
console.log(test);

let age1=20;
console.log(age1);

age1=6;
console.log(age1);

if(true)
{
    let insideBlock="WEB DEVELOPMENT";
    console.log(insideBlock);
}

const pi =3.1416;
console.log(pi);

if (true)
{
    const city="Islamabad";
    console.log(city);
}

let x=7;
let b=5;

console.log("Addition: "+ (x+b));
console.log("Subtraction: " + (x-b));
console.log("Multiplication: " + (x*b));
console.log("Division: " + (x/b));
console.log("Modulus: " + (x%b));

let marks=79;
if(marks>=90)
{
    console.log("Pass");
}
else {
    console.log("Fail");
}

for (let i = 0; i < 7; i++) { 
    console.log("Iteration: " + i);
}
const product={
    pname:"Chips",
    price:50,
    isAvailable:true,

}
console.log("Name:"+product.pname);
console.log("Price:"+product["price"]);
console.log("Availability:"+product.isAvailable);
product["pname"]="Chips";
console.log(product.pname);

let a1=9;
let b1=4;
console.log("a1=",a1,"& b1=",b1);
console.log("a1++ =",a1++);
console.log("a1=",a1++);

var fruit=prompt("Which fruit do you want");
switch(fruit)
{
    case "Apple":
        console.log("Enjoy your apples!");
        break;
    case "Kiwi": 
        console.log("Enjoy your kiwi!");
        break;
    case"Grapes":
         console.log("Enjoy your grapes");
         break;
   default:
    console.log("Fruits not available");
    break;
}

const person1 = {
    fname: "Amna",
    lname: "Zahood",
    age: 20
};

let text = "";
for (let s in person1) {
    text += person1[s] + " ";
}
console.log(text);

const Cars=["Audi","BMW","Sonata"];
let text1="";
for(let c of Cars)
{
    text1+= c+" ";
}
console .log(text1);

let n1=13;
console.log(typeof n1);

let n2=13.5;
console.log(typeof n2);

let n3="HI";
console.log(typeof n3);''